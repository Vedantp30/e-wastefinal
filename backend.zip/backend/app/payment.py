from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from .models import db, Payment, User

bp = Blueprint('payment', __name__, url_prefix='/api')

@bp.route('/payment', methods=['POST'])
@jwt_required()
def create_payment():
    data = request.get_json()
    user_email = get_jwt_identity()['email']
    user = User.query.filter_by(email=user_email).first()
    if not user:
        return jsonify({'message': 'User not found'}), 404
    payment = Payment(
        user_id=user.id,
        amount=data['amount'],
        method=data['method']
    )
    db.session.add(payment)
    db.session.commit()
    return jsonify({'message': 'Payment processed successfully'}), 201
