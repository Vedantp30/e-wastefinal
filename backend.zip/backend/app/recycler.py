from flask import Blueprint, request, jsonify
from .models import db, Recycler

bp = Blueprint('recycler', __name__, url_prefix='/api')

@bp.route('/recyclers', methods=['GET'])
def get_recyclers():
    recyclers = Recycler.query.all()
    return jsonify([{
        'id': recycler.id,
        'name': recycler.name,
        'serviceArea': recycler.service_area,
        'typesOfEwaste': recycler.types_of_ewaste,
        'processingMethods': recycler.processing_methods
    } for recycler in recyclers])

@bp.route('/recycler/<int:id>', methods=['GET'])
def get_recycler(id):
    recycler = Recycler.query.get_or_404(id)
    return jsonify({
        'id': recycler.id,
        'name': recycler.name,
        'serviceArea': recycler.service_area,
        'typesOfEwaste': recycler.types_of_ewaste,
        'processingMethods': recycler.processing_methods
    })
