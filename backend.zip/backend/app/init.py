from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from flask_cors import CORS

db = SQLAlchemy()
bcrypt = Bcrypt()
jwt = JWTManager()

def create_app():
    app = Flask(__name__)
    CORS(app)
    app.config.from_object('config.Config')

    db.init_app(app)
    bcrypt.init_app(app)
    jwt.init_app(app)

    with app.app_context():
        from . import routes, auth, collection, recycler, payment
        app.register_blueprint(routes.bp)
        app.register_blueprint(auth.bp)
        app.register_blueprint(collection.bp)
        app.register_blueprint(recycler.bp)
        app.register_blueprint(payment.bp)
        db.create_all()

    return app
