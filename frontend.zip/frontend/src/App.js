import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import Profile from './components/Profile/Profile';
import CollectionRequest from './components/Collection/CollectionRequest';
import RecyclerList from './components/Recycler/RecyclerList';
import RecyclerProfile from './components/Recycler/RecyclerProfile';
import PaymentForm from './components/Payment/PaymentForm';
import './theme.css';

const App = () => {
    return (
        <AuthProvider>
            <Router>
                <Navbar />
                <Switch>
                    <Route path="/login" component={Login} />
                    <Route path="/signup" component={Signup} />
                    <Route path="/profile" component={Profile} />
                    <Route path="/collection" component={CollectionRequest} />
                    <Route path="/recyclers" component={RecyclerList} />
                    <Route path="/recycler/:id" component={RecyclerProfile} />
                    <Route path="/payment" component={PaymentForm} />
                    {/* Add other routes as needed */}
                </Switch>
            </Router>
        </AuthProvider>
    );
};

export default App;
