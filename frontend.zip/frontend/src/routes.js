import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import Profile from './components/Profile/Profile';
import CollectionRequest from './components/Collection/CollectionRequest';
import RecyclerList from './components/Recycler/RecyclerList';
import RecyclerProfile from './components/Recycler/RecyclerProfile';
import PaymentForm from './components/Payment/PaymentForm';

const Routes = () => (
    <Switch>
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/profile" component={Profile} />
        <Route path="/collection" component={CollectionRequest} />
        <Route path="/recyclers" component={RecyclerList} />
        <Route path="/recycler/:id" component={RecyclerProfile} />
        <Route path="/payment" component={PaymentForm} />
        {/* Add other routes as needed */}
    </Switch>
);

export default Routes;
