import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

const CollectionRequest = () => {
    const { user } = useAuth();
    const [formData, setFormData] = useState({
        item: '',
        quantity: '',
        date: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const response = await fetch('http://localhost:5000/api/collection', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${user.token}`
            },
            body: JSON.stringify(formData),
        });
        const data = await response.json();
        console.log(data);
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="item" placeholder="Item" onChange={handleChange} required />
            <input type="number" name="quantity" placeholder="Quantity" onChange={handleChange} required />
            <input type="date" name="date" onChange={handleChange} required />
            <button type="submit">Request Collection</button>
        </form>
    );
};

export default CollectionRequest;
