import React from 'react';

const Invoice = ({ invoice }) => {
    return (
        <div>
            <h2>Invoice</h2>
            <p>Amount: {invoice.amount}</p>
            <p>Date: {invoice.date}</p>
            <p>Status: {invoice.status}</p>
        </div>
    );
};

export default Invoice;
