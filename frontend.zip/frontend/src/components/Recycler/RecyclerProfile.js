import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const RecyclerProfile = () => {
    const { id } = useParams();
    const [recycler, setRecycler] = useState(null);

    useEffect(() => {
        const fetchRecycler = async () => {
            const response = await fetch(`http://localhost:5000/api/recycler/${id}`);
            const data = await response.json();
            setRecycler(data);
        };

        fetchRecycler();
    }, [id]);

    if (!recycler) return <div>Loading...</div>;

    return (
        <div>
            <h2>{recycler.name}</h2>
            <p>Service Area: {recycler.serviceArea}</p>
            <p>Types of E-Waste Accepted: {recycler.typesOfEwaste.join(', ')}</p>
            <p>Processing Methods: {recycler.processingMethods}</p>
        </div>
    );
};

export default RecyclerProfile;
