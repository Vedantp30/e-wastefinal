import React, { useEffect, useState } from 'react';

const RecyclerList = () => {
    const [recyclers, setRecyclers] = useState([]);

    useEffect(() => {
        const fetchRecyclers = async () => {
            const response = await fetch('http://localhost:5000/api/recyclers');
            const data = await response.json();
            setRecyclers(data);
        };

        fetchRecyclers();
    }, []);

    return (
        <div>
            <h2>Recycler List</h2>
            <ul>
                {recyclers.map(recycler => (
                    <li key={recycler.id}>{recycler.name} - {recycler.serviceArea}</li>
                ))}
            </ul>
        </div>
    );
};

export default RecyclerList;
